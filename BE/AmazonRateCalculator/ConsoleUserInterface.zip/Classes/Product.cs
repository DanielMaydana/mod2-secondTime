﻿namespace Model
{
    public class Product
    {
        public int quantity { get; set; }
        public double weight { get; set; }
        public string category { get; set; }
    }
}
