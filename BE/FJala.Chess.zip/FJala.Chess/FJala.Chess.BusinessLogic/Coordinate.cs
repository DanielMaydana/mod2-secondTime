﻿namespace FJala.Chess.BusinessLogic
{
    public class Coordinate
    {
        public uint x { get;  }
        public uint y { get; }
        public Coordinate(uint x, uint y)
        {
            this.x = x;
            this.y = y;
        }
    }
}
