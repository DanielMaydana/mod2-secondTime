﻿using System;

namespace FJala.Chess.BusinessLogic
{
    public enum Rows : uint
    {
        a,
        b,
        c,
        d,
        e,
        f,
        g,
        h
    }
}
