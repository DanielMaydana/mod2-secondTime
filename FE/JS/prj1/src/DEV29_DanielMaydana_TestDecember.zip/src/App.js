import React from 'react';
import TeamView from './views/TeamView';
import './App.css';

function App() {

  // const aux = {
  //   img: "http://www.bbk.ac.uk/mce/wp-content/uploads/2015/03/8327142885_9b447935ff.jpg",
  //   name: "Daniel Maydana",
  //   mail: "gmail.com",
  //   teams: 4
  // }

  return (
    <div className="App">
      <TeamView />
    </div>
  );
}

export default App;