﻿namespace FJala.Chess.BusinessLogic
{
    public class Board
    {
    }
}
